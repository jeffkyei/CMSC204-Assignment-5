package jkyeiasare1;

public class TreeNode<T> {
	private T dataNode; //reference to data
	private TreeNode<T> rightNode; //reference to right
	private TreeNode<T> leftNode; //refernece to left
	
	/*
	 * NOTES:
	 * 
	 * map with string, string - key is the morese code, value is the letter
	 * 
	 * Map<String, String> map = new TreeMap<String, String>();
	 * 
	 * add to the map:
	 * map.put("morse", "letter");
	 * 
	 * 
	 * ^^to create the MAP
	 * 
	 * 
	 * now create the tree:
	 * 
	 * TreeNode node = new TreeNode(code, result);
	 * ^creates a new node
	 * 
	 * if treesize = 0, root = node;
	 * 
	 * insertAuxiliaryMethod(root, code, result):
	 * 
	 * 
	 * create an auxiliary method to be recursive and run through three and insert properly:
	 * 
	 * insertAux(Node node, T code, T result){
	 *look at my methods that end with "aux" to see how i go from left to right
	 * }
	 * 
	 * splice the "code" string into each individual character
	 * if statement - if "." then 
	 * 
	 */
	
	
	
	
	
	public TreeNode(T dataNode) { //set left & right = null, data = dataNode
		this.dataNode = dataNode;
		rightNode = null;
		leftNode = null;
		
	}
	
	public TreeNode<T> getLeftNode() {
		return leftNode;
	}
	
	public TreeNode<T> getRightNode() {
		return rightNode;
	}
	
	public void setLeftNode(TreeNode<T> leftNode) {
		this.leftNode = leftNode;
	}
	
	public void setRightNode(TreeNode<T> rightNode) {
		this.rightNode = rightNode;
	}
	
	public TreeNode(TreeNode<T> node ) { //used for deep copies
		
	}

	public T getData() {
		return this.dataNode;
	}
}
