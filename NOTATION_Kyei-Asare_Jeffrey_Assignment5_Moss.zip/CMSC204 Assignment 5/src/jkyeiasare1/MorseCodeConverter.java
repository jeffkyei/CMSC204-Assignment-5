package jkyeiasare1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MorseCodeConverter {
//	private static MorseCodeTree tree;
	
	MorseCodeConverter(){
//		tree = new MorseCodeTree();
		
		
	}

	public static String convertToEnglish(String code) {	
		MorseCodeTree tree = new MorseCodeTree();
		//System.out.println(tree.toArrayList());

		
		//add code 
		
		//space means new letter, slash means new word

		String codeForLetter = "";
		String english = "";
		
		for(int i = 0; i < code.length(); i++) { //traverse through morsecode
			
			if(!(code.charAt(i) == (' '))){ 
				//when NOT a space, still in the same letter, so call fetch
				codeForLetter += code.charAt(i);
			}else if ((code.charAt(i) == (' '))){
				//if does equal space, done with that letter
				
//				tree.insert(codeForLetter, tree.fetch(codeForLetter));
				
				english += tree.fetch(codeForLetter); //this gives u the alpha letter
				codeForLetter = ""; //reset to blank
			}else if((code.charAt(i) == ('/'))) {
				//if slash, new word, so add space to english
				english += " ";
			}
			
		}
		return english;		
		
	}

	public static Object convertToEnglish(File file) throws FileNotFoundException{
		String english = "";

		try {
			Scanner scan = new Scanner(file);
						
			while(scan.hasNextLine()) {
				english += convertToEnglish(scan.next());
			}
		}
		catch (FileNotFoundException e){
			System.out.println("No file was found.");
			e.printStackTrace();
		}
		
		return english;
	}

	public static Object printTree() {
//		return tree.toArrayList();
		return null;
	}
	
}
