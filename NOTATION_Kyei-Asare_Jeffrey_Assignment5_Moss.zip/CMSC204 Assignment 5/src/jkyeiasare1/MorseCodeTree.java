package jkyeiasare1;

import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

public class MorseCodeTree<T> implements LinkedConverterTreeInterface{
	
//	private T data; //data
	private int size; //size
//	private TreeNode<String> left; //left
//	private TreeNode<String> right; //right
	TreeNode<String> root; //root
	
	public MorseCodeTree() { //call method buildTree //done
		size = 0;
		
		this.buildTree();
		
		//the map from buildtree is never used so tree is null 

//		size = 0;
//		data = null;
//		left = null;
//		right = null;
//		root = new TreeNode<String>(" ");
	}
	@Override
	public TreeNode getRoot() { //done
		return this.root;
	}

	@Override
	public void setRoot(TreeNode newNode) { //setter for root //done
		root = newNode;
		
	}

	@Override
	public void insert(Object code, Object result) { //add result to tree based on morsecodde //done
		// Add result to tree based on code
		addNode(root, code, result);
		
	}

	@Override
	public void addNode(TreeNode node, Object code, Object letter) { //done
		//add letter to tree based on code
		
		//letter is the data of the node
		
		auxAddNode(node, code, letter);
	}
	
	public TreeNode<String> auxAddNode(TreeNode node, Object code, Object letter) { //auxillary method			
		
		TreeNode newNode = new TreeNode(letter);
		
		if(node == null) {
			//create a new node and add it
			//node = newNode;
			//return newNode;
			
			if(size == 0) {
				root = newNode; //update root
			}else {
				node = newNode;
			}
			size++;
			return newNode;
			
		}else {
			
//			System.out.println("Node: " + node.getData());
//			System.out.println("Left of node: " + left.toString());
//			System.out.println("Right of node: " + right.toString());
					
			if(((String)code).length() > 1) {
				//for(int i = 0; i<((String)code).length(); i++) {
//					String codeSub = ((String) code).substring(i);
					
//					TreeNode newNode = new TreeNode(letter);
					
					if(((String)code).charAt(0) == ('.')) { //set left node
//						left = newNode;
						
						node.setLeftNode(auxAddNode(node.getLeftNode(), ((String) code).substring(1), letter));
						
//						auxAddNode(node, ((String) code).substring(i+1), letter);
						
//						size++;
					}else if(((String)code).charAt(0) == ('-')) {
//						right = newNode;
						
						node.setRightNode(auxAddNode(node.getRightNode(), ((String) code).substring(1), letter));
						
//						auxAddNode(node, ((String) code).substring(i+1), letter);

//						size++;
					}
				}
			else {
				//if code.length = 1
//				TreeNode newNode = new TreeNode(letter);

				if(((String)code).equals(".")) {
					//keeps resetting left
//					left = newNode;
					
					node.setLeftNode(newNode);
					
//					auxAddNode(node, ((String) code).substring(i+1), letter);
					
//					size++;
				}else if(((String)code).equals("-")) {
//					right = newNode;
					
					node.setRightNode(newNode);
					
//					auxAddNode(node, ((String) code).substring(i+1), letter);

//					size++;
				}
			}

			
		size++;
		return node;
		}
			
	}
		

	@Override
	public Object fetch(String code) { //return letter at morse code key, calls fetchNode
		return fetchNode(root, code);
	}

	@Override
	public Object fetchNode(TreeNode node, Object code) { //return letter based off morse code key
		if(node == null) {
			return null;
		}else {
			for(int i = 0; i<((String)code).length(); i++) {
//				String codeSub = ((String) code).substring(i);
				
//				if(((String)code).substring(i).equals(".")) {
				if(((String) code).charAt(i) == ('.')) {
					return fetchNode(node.getLeftNode(), ((String) code).substring(i+1));
				}else if(((String) code).charAt(i) == ('-')) {
					return fetchNode(node.getRightNode(), ((String) code).substring(i+1));
				}
			}
			
			return node.getData();
		}		
		
		
	}

	@Override
	public LinkedConverterTreeInterface delete(Object data) throws UnsupportedOperationException { //deletes letter at node
		// TODO Auto-generated method stub
		
		if(this instanceof LinkedConverterTreeInterface) {
			throw new UnsupportedOperationException("Linked Converter Tree not supported");
		}
		
		deleteAux(root, data);
		
		
		return null;
	}
	
	private TreeNode deleteAux(TreeNode node, Object data) {
		if(node == null) {
			return null;
		}else if(node.getData() == data) {
			//node to delete
			if(node.getLeftNode() == null && node.getRightNode() == null) {
				//no children
				node = null;
				size--;
			}else if(node.getLeftNode() == null) {
				//has only right child
				node = node.getLeftNode();
				size--;
			}else if(node.getRightNode() == null) {
				//has only left child
				node = node.getRightNode();
				size--;
			}else {
				//has both children
				
				MorseCodeTree subtree = new MorseCodeTree();
				subtree.root = node;
				
				//sort by level - has to have 4 characters
				//as far left in the right subtree
				//only 6 possible values to replace it with
				
				
				
				
				
				
			}
				
		}else {
			//go to next node
			node.setLeftNode(deleteAux(node.getLeftNode(), data));
			node.setRightNode(deleteAux(node.getRightNode(), data));
		}
		return node;
		
	}

	@Override
	public LinkedConverterTreeInterface update() throws UnsupportedOperationException { //updates tree
		if(this instanceof LinkedConverterTreeInterface) {
			throw new UnsupportedOperationException("This operation is not supported for a LinkedConverterTree");
		}
		
		return this;
	}

	@Override
	public void buildTree() {
		this.insert(" ", " "); //root is space
		this.insert(".", "e"); //put . with e, level 1 left node
		this.insert("-", "t"); //put - with t, level 1 right node
		this.insert("..", "i"); //put .. with i, level 2 leftmost node
		this.insert(".-", "a");
		this.insert("-.", "n");
		this.insert("--", "m");
		this.insert("...", "s");
		this.insert("..-", "u");
		this.insert(".-.", "r");
		this.insert(".--", "w");
		this.insert("-..", "d");
		this.insert("-.-", "k");
		this.insert("--.", "g");
		this.insert("---", "o");
		this.insert("....", "h");
		this.insert("...-", "v");
		this.insert("..-.", "f");
		this.insert(".-..", "l");
		this.insert(".--.", "p");
		this.insert(".---", "j");
		this.insert("-...", "b");
		this.insert("-..-", "x");
		this.insert("-.-.", "c");
		this.insert("-.--", "y");
		this.insert("--..", "z");
		this.insert("--.-", "q");
		
		
//		return this.toArrayList();
		
	}

	@Override
	public ArrayList toArrayList() {		
		//iterate through tree in inorder order (left, parent, right)
		//add to arraylist
		
		ArrayList<String> list = new ArrayList<String>();
		
		LNRoutputTraversal(root, list);
		
		return list;
	}

	@Override
	public void LNRoutputTraversal(TreeNode node, ArrayList list) {
		if(node != null) {
			LNRoutputTraversal(node.getLeftNode(), list);
			list.add((String) node.getData());
			LNRoutputTraversal(node.getRightNode(), list);
		}
	}

}
