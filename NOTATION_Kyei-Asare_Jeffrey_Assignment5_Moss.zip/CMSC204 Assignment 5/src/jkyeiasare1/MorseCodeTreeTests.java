package jkyeiasare1;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MorseCodeTreeTests {
	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}
	
	@Test
	public void constructorTest() {	
		MorseCodeTree newTree = new MorseCodeTree();
		System.out.println(newTree.toArrayList());
		
		assertEquals(" ", newTree.getRoot());
	}
	
	@Test
	public void getSetRoot() {
		MorseCodeTree newTree = new MorseCodeTree();
		
		TreeNode newNode = new TreeNode("a");
		
		newTree.setRoot(newNode);
		
		assertEquals("a", newTree.getRoot());
	}
	
	@Test
	public void insertAndFetchTest() {
		MorseCodeTree newTree = new MorseCodeTree();
		
		newTree.insert("----------", "a"); //random, not true
		
		assertEquals("a", newTree.fetch("----------"));
	}
	
	@Test
	public void addTest() {
		MorseCodeTree newTree = new MorseCodeTree();
		
		newTree.addNode(newTree.getRoot(), "----------", "a"); //insert at root
		
		assertEquals("a", newTree.getRoot());
	}
	
	@Test
	public void updateTest() {
		MorseCodeTree newTree = new MorseCodeTree();

		assertEquals(newTree, newTree.update());
	}
	
	@Test
	public void arrayTest() {
		MorseCodeTree newTree = new MorseCodeTree();

		ArrayList list = new ArrayList<>();
		list.add("a");
		list.add("b");
		list.add("c");
		list.add("d");
		list.add("e");
		list.add("f");
		list.add("g");
		list.add("h");
		list.add("i");
		list.add("j");
		list.add("k");
		list.add("l");
		list.add("m");
		list.add("o");
		list.add("p");
		list.add("q");
		list.add("r");
		list.add("s");
		list.add("t");
		list.add("u");
		list.add("v");
		list.add("w");
		list.add("x");
		list.add("y");
		list.add("z");
		
		assertEquals(list, newTree.toArrayList());
	}
	
	
}
